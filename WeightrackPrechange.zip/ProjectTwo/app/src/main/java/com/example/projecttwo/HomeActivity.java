package com.example.projecttwo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    DatabaseHelper db;
    TextView goalWeightText;
    private static final String USER_PREFS = "UserPrefs";
    private static final String USER_ID_KEY = "userId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);

        db = new DatabaseHelper(this);
        goalWeightText = findViewById(R.id.goalWeight);

        Button addWeightButton = findViewById(R.id.addWeightButton);
        Button smsButton = findViewById(R.id.smsButton);

        addWeightButton.setOnClickListener(v -> startActivity(new Intent(this, AddWeightActivity.class)));
        smsButton.setOnClickListener(v -> startActivity(new Intent(this, SmsSettingsActivity.class)));

        loadGoalWeight();
        loadLastWeights();
    }

    /** Loads the goal weight for the logged-in user */
    private void loadGoalWeight() {
        SharedPreferences prefs = getSharedPreferences(USER_PREFS, MODE_PRIVATE);
        int userId = prefs.getInt(USER_ID_KEY, -1);
        if (userId == -1) return;

        SQLiteDatabase database = db.getReadableDatabase();
        Cursor cursor = database.rawQuery(
                "SELECT goal_weight FROM goal WHERE user_id = ? LIMIT 1",
                new String[]{String.valueOf(userId)}
        );

        if (cursor.moveToFirst()) {
            goalWeightText.setText("Goal Weight: " + cursor.getDouble(0));
        } else {
            goalWeightText.setText("Goal Weight: Not Set");
        }

        cursor.close();
    }

    /** Loads the last four weights for the logged-in user */
    private void loadLastWeights() {
        SharedPreferences prefs = getSharedPreferences(USER_PREFS, MODE_PRIVATE);
        int userId = prefs.getInt(USER_ID_KEY, -1);
        if (userId == -1) return;

        TextView w1 = findViewById(R.id.Weight1);
        TextView w2 = findViewById(R.id.Weight2);
        TextView w3 = findViewById(R.id.Weight3);
        TextView w4 = findViewById(R.id.Weight4);

        SQLiteDatabase database = db.getReadableDatabase();
        Cursor cursor = database.rawQuery(
                "SELECT weight FROM weights WHERE user_id = ? ORDER BY id DESC LIMIT 4",
                new String[]{String.valueOf(userId)}
        );

        TextView[] boxes = {w1, w2, w3, w4};
        int i = 0;
        while (cursor.moveToNext() && i < 4) {
            boxes[i].setText(cursor.getString(0));
            i++;
        }

        cursor.close();
    }
}