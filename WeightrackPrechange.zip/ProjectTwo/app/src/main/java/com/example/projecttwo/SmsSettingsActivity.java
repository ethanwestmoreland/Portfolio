package com.example.projecttwo;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.Switch;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsSettingsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;
    private static final String PREFS_NAME = "WeightPrefs";
    private static final String SMS_ENABLED_KEY = "smsEnabled";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms);

        Switch smsSwitch = findViewById(R.id.switch1);
        Button backButton = findViewById(R.id.backButton);

        // Load saved SMS notification preference
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        smsSwitch.setChecked(prefs.getBoolean(SMS_ENABLED_KEY, false));

        // Toggle SMS notifications
        smsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean(SMS_ENABLED_KEY, isChecked);
            editor.apply();

            if (isChecked) {
                requestSmsPermission();
            }
        });

        // Return to home
        backButton.setOnClickListener(v -> startActivity(new Intent(this, HomeActivity.class)));
    }

    /** Requests SEND_SMS permission if not already granted */
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        } else {
            sendTestSms();
        }
    }

    /** Sends a test SMS notification to verify SMS is working */
    private void sendTestSms() {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(
                "7068531385",
                null,
                "WeightTrack: Keep up the great work toward your goal!",
                null,
                null
        );
    }
}