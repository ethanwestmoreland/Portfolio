package com.example.projecttwo;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class SetGoalActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "WeightPrefs";
    private static final String SMS_ENABLED_KEY = "smsEnabled";
    private static final String USER_PREFS = "UserPrefs";
    private static final String USER_ID_KEY = "userId";

    DatabaseHelper db;
    EditText goalBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.goalweight);

        db = new DatabaseHelper(this);
        goalBox = findViewById(R.id.weightBox2);

        Button setGoalButton = findViewById(R.id.addWeightButton3);
        Button backButton = findViewById(R.id.backButton);

        backButton.setOnClickListener(v -> startActivity(new Intent(this, HomeActivity.class)));
        setGoalButton.setOnClickListener(v -> saveGoal());
    }

    /** Saves or updates the user's goal weight */
    private void saveGoal() {
        double goal = Double.parseDouble(goalBox.getText().toString());

        SharedPreferences prefs = getSharedPreferences(USER_PREFS, MODE_PRIVATE);
        int userId = prefs.getInt(USER_ID_KEY, -1);
        if (userId == -1) return;

        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("goal_weight", goal);

        SQLiteDatabase database = db.getWritableDatabase();
        database.delete("goal", "user_id = ?", new String[]{String.valueOf(userId)});
        database.insert("goal", null, values);

        if (isSmsEnabled()) {
            sendGoalSms(goal);
        }

        finish();
    }

    private boolean isSmsEnabled() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getBoolean(SMS_ENABLED_KEY, false);
    }

    private void sendGoalSms(double goal) {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(
                "5551234567",
                null,
                "WeightTrack: Your new goal weight is set to " + goal,
                null,
                null
        );
    }
}