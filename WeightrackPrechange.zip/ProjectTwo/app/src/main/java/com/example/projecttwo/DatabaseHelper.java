package com.example.projecttwo;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * DatabaseHelper handles the creation and management of the SQLite database
 * for the WeightTrack app, including user login info, daily weights, and goal weights.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database constants
    private static final String DATABASE_NAME = "weighttrack.db";
    private static final int DATABASE_VERSION = 1;

    /**
     * Constructor - initializes the database helper
     */
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Called when the database is first created.
     * Creates the users, weights, and goal tables.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {

        // User login table
        db.execSQL(
                "CREATE TABLE users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT, " +
                        "password TEXT)"
        );

        // Daily weights table
        db.execSQL(
                "CREATE TABLE weights (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_id INTEGER, " +
                        "weight REAL, " +
                        "date TEXT)"
        );

        // Goal weight table
        db.execSQL(
                "CREATE TABLE goal (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_id INTEGER, " +
                        "goal_weight REAL)"
        );
    }

    /**
     * Called when the database needs to be upgraded.
     * Drops the existing tables and recreates them.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop tables if they exist
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS weights");
        db.execSQL("DROP TABLE IF EXISTS goal");

        // Recreate tables
        onCreate(db);
    }
}