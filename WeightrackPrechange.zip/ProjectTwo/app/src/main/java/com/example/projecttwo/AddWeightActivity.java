package com.example.projecttwo;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.time.LocalDate;

public class AddWeightActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "WeightPrefs";
    private static final String SMS_ENABLED_KEY = "smsEnabled";
    private static final String USER_PREFS = "UserPrefs";
    private static final String USER_ID_KEY = "userId";

    DatabaseHelper db;
    EditText weightBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addweight);

        db = new DatabaseHelper(this);
        weightBox = findViewById(R.id.weightBox);

        Button addWeightButton = findViewById(R.id.addWeightButton2);
        Button editGoalButton = findViewById(R.id.editGoalButton);
        Button homeButton = findViewById(R.id.returnToHome);

        addWeightButton.setOnClickListener(v -> addWeight());
        editGoalButton.setOnClickListener(v -> startActivity(new Intent(this, SetGoalActivity.class)));
        homeButton.setOnClickListener(v -> startActivity(new Intent(this, HomeActivity.class)));
    }

    /** Inserts a new weight record into the database for the logged-in user */
    private void addWeight() {
        double weight = Double.parseDouble(weightBox.getText().toString());

        SharedPreferences prefs = getSharedPreferences(USER_PREFS, MODE_PRIVATE);
        int userId = prefs.getInt(USER_ID_KEY, -1);
        if (userId == -1) return; // Safety check

        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("weight", weight);
        values.put("date", LocalDate.now().toString());

        SQLiteDatabase database = db.getWritableDatabase();
        database.insert("weights", null, values);

        if (isSmsEnabled()) {
            sendSmsNotification(weight);
        }

        startActivity(new Intent(this, HomeActivity.class));
    }

    private boolean isSmsEnabled() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getBoolean(SMS_ENABLED_KEY, false);
    }

    private void sendSmsNotification(double weight) {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(
                "5551234567",
                null,
                "WeightTrack: New weight recorded: " + weight,
                null,
                null
        );
    }
}