package com.example.projecttwo;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    DatabaseHelper db;
    EditText usernameBox, passwordBox;
    Button loginButton, createButton;

    private static final String USER_PREFS = "UserPrefs";
    private static final String USER_ID_KEY = "userId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        db = new DatabaseHelper(this);

        usernameBox = findViewById(R.id.usernameBox);
        passwordBox = findViewById(R.id.passwordBox);
        loginButton = findViewById(R.id.loginButton);
        createButton = findViewById(R.id.loginButton2);

        loginButton.setOnClickListener(v -> loginUser());
        createButton.setOnClickListener(v -> createUser());
    }

    /** Checks username and password and logs in the user if valid */
    private void loginUser() {
        SQLiteDatabase database = db.getReadableDatabase();
        Cursor cursor = database.rawQuery(
                "SELECT id FROM users WHERE username=? AND password=?",
                new String[]{usernameBox.getText().toString(), passwordBox.getText().toString()}
        );

        if (cursor.moveToFirst()) {
            int userId = cursor.getInt(0);

            // Save logged-in user ID in SharedPreferences
            SharedPreferences prefs = getSharedPreferences(USER_PREFS, MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putInt(USER_ID_KEY, userId);
            editor.apply();

            startActivity(new Intent(this, HomeActivity.class));
        }

        cursor.close();
    }

    /** Creates a new user account in the database */
    private void createUser() {
        SQLiteDatabase database = db.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", usernameBox.getText().toString());
        values.put("password", passwordBox.getText().toString());
        database.insert("users", null, values);
    }
}