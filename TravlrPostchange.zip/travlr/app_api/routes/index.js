const express = require('express');
const router = express.Router();

// Imports the controllers used to manage trips and user authentication.
const ctrlTrips = require('../controllers/trips');
const ctrlAuth = require('../controllers/authentication');

// Imports JWT authentication to protect certain API routes.
const { expressjwt: jwt } = require('express-jwt');

// Makes sure an authentication secret has been configured.
if (!process.env.JWT_SECRET) {
  throw new Error('JWT_SECRET must be configured');
}

// Checks authentication tokens before allowing protected requests.
const auth = jwt({
  secret: process.env.JWT_SECRET,
  algorithms: ['HS256']
});

// Public registration is disabled for security.
// Administrator accounts must be created separately.

// Allows existing administrators to log in.
router.post('/login', ctrlAuth.login);

// Allows users to view trips without logging in.
router.get('/trips', ctrlTrips.tripsList);
router.get('/trips/:tripId', ctrlTrips.tripsFindById);

// Requires authentication before adding, updating, or deleting trips.
router.post('/trips', auth, ctrlTrips.tripsAdd);
router.put('/trips/:tripId', auth, ctrlTrips.tripsUpdate);
router.delete('/trips/:tripId', auth, ctrlTrips.tripsDelete);

// Makes the API routes available to the application.
module.exports = router;