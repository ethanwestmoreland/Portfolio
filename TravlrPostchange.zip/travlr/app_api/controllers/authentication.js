const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const User = mongoose.model('users');

// Creates a new user account with the provided email and password.
const register = async (req, res) => {
  const user = new User();

  // Saves the email and securely hashes the password.
  user.email = req.body.email;
  user.setPassword(req.body.password);

  // Attempts to save the new user to the database.
  try {
    await user.save();
    res.status(200).json({ message: "User created" });
  } catch (err) {
    res.status(400).json(err);
  }
};

// Checks the user's login information and creates an authentication token.
const login = async (req, res) => {

  // Searches the database for an account with the entered email.
  const user = await User.findOne({ email: req.body.email });

  // Rejects the login if the account or password is incorrect.
  if (!user || !user.validPassword(req.body.password)) {
    return res.status(401).json({ message: "Invalid credentials" });
  }

  // Creates a login token that expires after two hours.
  const token = jwt.sign(
    { _id: user._id, email: user.email },
    process.env.JWT_SECRET,
    { expiresIn: '2h' }
  );

  // Sends the authentication token back to the application.
  res.status(200).json({ token });
};

// Makes the authentication functions available to the API routes.
module.exports = {
  register,
  login
};