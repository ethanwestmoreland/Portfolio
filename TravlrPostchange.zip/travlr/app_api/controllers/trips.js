const mongoose = require('mongoose');
const Trip = mongoose.model('trips');

// Defines which trip fields can be added or updated.
const allowedTripFields = [
  'name',
  'image',
  'description1',
  'description2'
];

// Filters incoming data to include only approved trip fields.
const filterTripData = (data) => {
  const filteredData = {};

  // Checks each allowed field and copies it if it was provided.
  for (const field of allowedTripFields) {
    if (Object.prototype.hasOwnProperty.call(data, field)) {
      filteredData[field] = data[field];
    }
  }

  return filteredData;
};

// Retrieves trips from the database using searching and pagination.
const tripsList = async (req, res) => {
  try {
    // Gets the requested page number and checks that it is valid.
    const pageInput = req.query.page ?? "1";
    const pageNumber = Number(pageInput);

    if (
      typeof pageInput !== "string" ||
      !Number.isSafeInteger(pageNumber) ||
      pageNumber < 1
    ) {
      return res.status(400).json({
        message: "Page must be a positive integer"
      });
    }

    // Limits each page to 10 trips and calculates which records to skip.
    const page = pageNumber;
    const limit = 10;
    const skip = (page - 1) * limit;

    // Prevents page numbers that would create an invalid database offset.
    if (!Number.isSafeInteger(skip)) {
      return res.status(400).json({
        message: "Page number is too large"
      });
    }

    // Gets the search term entered by the user.
    const search = typeof req.query.search === "string"
      ? req.query.search.trim()
      : "";

    // Creates a filter for searching trip information.
    const filter = {};

    if (search) {
      // Prevents special characters from changing the search pattern.
      const safeSearch = search.replace(
        /[.*+?^${}()|[\]\\]/g,
        "\\$&"
      );

      // Searches trip names and descriptions without case sensitivity.
      filter.$or = [
        { name: { $regex: safeSearch, $options: "i" } },
        { description1: { $regex: safeSearch, $options: "i" } },
        { description2: { $regex: safeSearch, $options: "i" } }
      ];
    }

    // Counts how many trips match the search.
    const totalTrips = await Trip.countDocuments(filter);

    // Retrieves matching trips in alphabetical order.
    // Only the records needed for the current page are returned.
    const trips = await Trip.find(filter)
      .sort({ name: 1, _id: 1 })
      .skip(skip)
      .limit(limit);

    // Calculates how many pages are needed for the matching trips.
    const totalPages = Math.ceil(totalTrips / limit);

    // Sends the trips and pagination information back to Angular.
    return res.status(200).json({
      trips: trips,
      pagination: {
        currentPage: page,
        totalPages: totalPages,
        totalTrips: totalTrips,
        tripsPerPage: limit
      }
    });

  } catch (err) {
    // Handles unexpected errors when retrieving trips.
    console.error("Error retrieving trips:", err);

    return res.status(500).json({
      message: "Unable to retrieve trips"
    });
  }
};

// Finds a specific trip in the database using its ID.
const tripsFindById = async (req, res) => {
  try {
    const trip = await Trip.findById(req.params.tripId);

    // Returns an error if the requested trip does not exist.
    if (!trip) {
      return res.status(404).json({
        message: "Trip not found"
      });
    }

    return res.status(200).json(trip);

  } catch (err) {
    // Handles trip IDs that are not in the correct format.
    if (err.name === 'CastError') {
      return res.status(400).json({
        message: "Invalid trip ID"
      });
    }

    // Handles unexpected errors when finding a trip.
    console.error("Error finding trip:", err);

    return res.status(500).json({
      message: "Unable to retrieve trip"
    });
  }
};

// Adds a new trip to the database.
const tripsAdd = async (req, res) => {
  try {
    // Filters the submitted information before creating the trip.
    const tripData = filterTripData(req.body);
    const trip = await Trip.create(tripData);

    return res.status(201).json(trip);

  } catch (err) {
    // Returns an error if the trip does not meet database requirements.
    if (err.name === 'ValidationError') {
      return res.status(400).json({
        message: "Invalid trip information",
        errors: Object.values(err.errors).map(
          error => error.message
        )
      });
    }

    // Handles unexpected errors when creating a trip.
    console.error("Error creating trip:", err);

    return res.status(500).json({
      message: "Unable to create trip"
    });
  }
};

// Updates an existing trip with new information.
const tripsUpdate = async (req, res) => {
  try {
    // Removes any fields that are not approved for updating.
    const tripData = filterTripData(req.body);

    // Stops the update if no valid trip information was provided.
    if (Object.keys(tripData).length === 0) {
      return res.status(400).json({
        message: "No valid trip fields provided"
      });
    }

    // Finds the trip and updates only the approved fields.
    // Database validation is enabled to check the updated values.
    const trip = await Trip.findByIdAndUpdate(
      req.params.tripId,
      { $set: tripData },
      {
        new: true,
        runValidators: true
      }
    );

    // Returns an error if the trip cannot be found.
    if (!trip) {
      return res.status(404).json({
        message: "Trip not found"
      });
    }

    return res.status(200).json(trip);

  } catch (err) {
    // Handles information that does not meet database requirements.
    if (err.name === 'ValidationError') {
      return res.status(400).json({
        message: "Invalid trip information",
        errors: Object.values(err.errors).map(
          error => error.message
        )
      });
    }

    // Handles trip IDs that are not in the correct format.
    if (err.name === 'CastError') {
      return res.status(400).json({
        message: "Invalid trip ID"
      });
    }

    // Handles unexpected errors when updating a trip.
    console.error("Error updating trip:", err);

    return res.status(500).json({
      message: "Unable to update trip"
    });
  }
};

// Deletes a trip from the database using its ID.
const tripsDelete = async (req, res) => {
  try {
    const trip = await Trip.findByIdAndDelete(req.params.tripId);

    // Returns an error if the trip does not exist.
    if (!trip) {
      return res.status(404).json({
        message: "Trip not found"
      });
    }

    return res.status(200).json({
      message: "Trip deleted successfully"
    });

  } catch (err) {
    // Handles trip IDs that are not in the correct format.
    if (err.name === 'CastError') {
      return res.status(400).json({
        message: "Invalid trip ID"
      });
    }

    // Handles unexpected errors when deleting a trip.
    console.error("Error deleting trip:", err);

    return res.status(500).json({
      message: "Unable to delete trip"
    });
  }
};

// Makes the trip functions available to the API routes.
module.exports = {
  tripsList,
  tripsFindById,
  tripsAdd,
  tripsUpdate,
  tripsDelete
};