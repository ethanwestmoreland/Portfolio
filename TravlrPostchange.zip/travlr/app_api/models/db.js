const mongoose = require('mongoose');

// Uses the database address from the environment or the local database.
const dbURI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/travlr';

// Connects the application to the MongoDB database.
mongoose.connect(dbURI);

// Displays a message when the database connects successfully.
mongoose.connection.on('connected', () => {
    console.log(`Mongoose connected to ${dbURI}`);
});

// Displays an error message if the database connection fails.
mongoose.connection.on('error', (err) => {
    console.log('Mongoose connection error: ' + err);
});

// Displays a message when the database disconnects.
mongoose.connection.on('disconnected', () => {
    console.log('Mongoose disconnected');
});

// Loads the trip and user database models.
require('./travlr');
require('./users');

// Closes the database connection before shutting down the application.
const gracefulShutdown = (msg, callback) => {
    mongoose.connection.close(() => {
        console.log(`Mongoose disconnected through ${msg}`);
        callback();
    });
};

// Closes the database connection when nodemon restarts the application.
process.once('SIGUSR2', () => {
    gracefulShutdown('nodemon restart', () => {
        process.kill(process.pid, 'SIGUSR2');
    });
});

// Closes the database connection when the application is stopped manually.
process.on('SIGINT', () => {
    gracefulShutdown('app termination', () => {
        process.exit(0);
    });
});

// Closes the database connection when the hosting service stops the application.
process.on('SIGTERM', () => {
    gracefulShutdown('Heroku app shutdown', () => {
        process.exit(0);
    });
});