const mongoose = require('mongoose');

const tripSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Trip name is required'],
        trim: true,
        minlength: [2, 'Trip name must be at least 2 characters'],
        maxlength: [100, 'Trip name cannot exceed 100 characters']
    },

    image: {
        type: String,
        default: 'default.jpg',
        trim: true
    },

    description1: {
        type: String,
        required: [true, 'Primary description is required'],
        trim: true,
        maxlength: [1000, 'Description is too long']
    },

    description2: {
        type: String,
        required: [true, 'Secondary description is required'],
        trim: true,
        maxlength: [1000, 'Description is too long']
    }
});

// Improve alphabetical sorting and pagination
tripSchema.index({ name: 1, _id: 1 });

mongoose.model('trips', tripSchema);