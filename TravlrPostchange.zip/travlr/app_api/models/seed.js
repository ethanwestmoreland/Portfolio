const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');

// Connects to the database and loads the trip model.
require('./db');
const Trip = mongoose.model('trips');

// Finds the JSON file containing the original trip information.
const tripsPath = path.join(__dirname, '../../data/trips.json');

// Reads the JSON file and converts its contents into usable data.
const tripsData = JSON.parse(fs.readFileSync(tripsPath, 'utf8'));

// Clears the existing trips and adds the trips from the JSON file.
const seedDB = async () => {
    try {
        // Removes all existing trips from the database.
        await Trip.deleteMany({});

        // Inserts the trip information from the JSON file.
        await Trip.insertMany(tripsData.trips);

        console.log('Database successfully seeded');

        // Closes the database connection when finished.
        mongoose.connection.close();

    } catch (err) {
        // Displays any errors and closes the database connection.
        console.log(err);
        mongoose.connection.close();
    }
};

// Starts the database seeding process.
seedDB();