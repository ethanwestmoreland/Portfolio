const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

// Defines how user account information is stored in the database.
const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true }
});

// Hashes the user's password before saving it to the database.
userSchema.methods.setPassword = function(password) {
  this.password = bcrypt.hashSync(password, 10);
};

// Checks whether the entered password matches the saved password hash.
userSchema.methods.validPassword = function(password) {
  return bcrypt.compareSync(password, this.password);
};

// Registers the user model so it can be used throughout the application.
mongoose.model('users', userSchema);