import { Component, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { TripDataService } from '../trip-data';
import { Trip } from '../trip';
import { Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

// Handles the form used to add new trips or edit existing trips.
@Component({
  selector: 'app-trip-form',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './trip-form.html',
  styleUrls: ['./trip-form.css']
})
export class TripFormComponent {

  // Tracks whether the user is editing an existing trip.
  isEditing: boolean = false;

  // Receives the selected trip and sends an event when editing is canceled.
  @Input() selectedTrip: any = null;
  @Output() cancel = new EventEmitter<void>();

  // Stores the information entered into the trip form.
  newTrip: Trip = {
    name: '',
    image: '',
    description1: '',
    description2: ''
  };

  constructor(private tripService: TripDataService) { }

  // Updates the form when a trip is selected for editing.
  ngOnChanges() {
    if (this.selectedTrip) {
      this.newTrip = { ...this.selectedTrip };
      this.isEditing = true;
    } else {
      this.resetForm();
      this.isEditing = false;
    }
  }

  // Clears the form and notifies the parent component.
  onCancel() {
    this.resetForm();
    this.cancel.emit();
  }

  // Saves the entered information by adding or updating a trip.
  saveTrip() {

    // Collects the trip information that will be sent to the API.
    const tripData = {
      name: this.newTrip.name,
      image: this.newTrip.image,
      description1: this.newTrip.description1,
      description2: this.newTrip.description2
    };

    // Updates the trip if an existing trip was selected.
    if (this.selectedTrip && this.selectedTrip._id) {
      this.tripService.updateTrip(this.selectedTrip._id, tripData).subscribe({
        next: () => {
          alert('Trip updated!');
          this.resetForm();
          window.location.reload();
        },
        error: (err) => console.error(err)
      });

    } else {

      // Creates a new trip if no existing trip was selected.
      this.tripService.addTrip(tripData).subscribe({
        next: () => {
          alert('Trip added!');
          this.resetForm();
          window.location.reload();
        },
        error: (err) => console.error(err)
      });
    }
  }

  // Resets the form fields and clears the current selection.
  resetForm() {
    this.newTrip = {
      name: '',
      image: '',
      description1: '',
      description2: ''
    };

    this.cancel.emit();
  }
}