import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs';
import { CommonModule } from '@angular/common';
import { TripDataService, TripResponse } from '../trip-data';
import { Trip } from '../trip';
import { TripFormComponent } from '../trip-form/trip-form';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

// Displays the trip list and allows users to manage trips.
@Component({
  selector: 'app-trip-list',
  standalone: true,
  imports: [CommonModule, FormsModule, TripFormComponent],
  templateUrl: './trip-list.html',
  styleUrls: ['./trip-list.css']
})

export class TripListComponent implements OnInit {

  // Stores the trips and pagination information received from the API.
  trips$!: Observable<TripResponse>;

  // Keeps track of the trip currently selected for editing.
  selectedTrip: Trip | null = null;

  constructor(
    private tripService: TripDataService,
    private router: Router
  ) { }

  // Checks whether a login token is stored in the browser.
  isLoggedIn(): boolean {
    return !!localStorage.getItem('travlr-token');
  }

  // Keeps track of the current page and search term.
  currentPage = 1;
  searchTerm = '';

  // Searches for matching trips and returns to the first page.
  searchTrips(): void {
    this.currentPage = 1;
    this.loadTrips();
  }

  // Moves to the next page if another page is available.
  nextPage(totalPages: number): void {
    if (this.currentPage < totalPages) {
      this.currentPage++;
      this.loadTrips();
    }
  }

  // Moves to the previous page without going below page one.
  previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.loadTrips();
    }
  }

  // Loads the trip information when the component first opens.
  ngOnInit(): void {
    this.loadTrips();
  }

  // Requests trips from the API using the current page and search term.
  loadTrips(): void {
    this.trips$ = this.tripService.getTrips(
      this.currentPage,
      this.searchTerm
    );
  }

  // Selects a trip so its information can be edited.
  selectTrip(trip: Trip) {
    this.selectedTrip = trip;
  }

  // Clears the selected trip when editing is canceled.
  cancelEdit() {
    this.selectedTrip = null;
  }

  // Removes the saved login token and clears the selected trip.
  logout() {
    localStorage.removeItem('travlr-token');
    this.selectedTrip = null;
  }

  // Sends the user to the login page.
  goToLogin() {
    this.router.navigate(['/login']);
  }

  // Deletes a selected trip after asking the user for confirmation.
  deleteTrip(id: string | undefined) {
    console.log("DELETE CLICKED", id);

    // Stops the process if the trip does not have an ID.
    if (!id) return;

    if (confirm('Are you sure you want to delete this trip?')) {
      this.tripService.deleteTrip(id).subscribe({
        next: () => {
          console.log("DELETE SUCCESS");
          alert('Trip deleted!');
          window.location.reload();
        },
        error: (err) => console.error("DELETE ERROR", err)
      });
    }
  }
}