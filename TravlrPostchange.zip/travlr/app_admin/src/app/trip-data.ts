import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Trip } from './trip';

// Defines the trip data and pagination information returned by the API.
export interface TripResponse {
  trips: Trip[];
  pagination: {
    currentPage: number;
    totalPages: number;
    totalTrips: number;
    tripsPerPage: number;
  };
}

@Injectable({
  providedIn: 'root'
})

export class TripDataService {

  // Stores the API address used to access trip information.
  private apiBaseUrl = 'http://localhost:3000/api/trips';

  constructor(private http: HttpClient) { }

  // Gets the saved login token for requests that require authentication.
  getAuthHeaders() {
    const token = localStorage.getItem('travlr-token');

    return {
      headers: {
        Authorization: `Bearer ${token}`
      }
    };
  }

  // Retrieves trips from the database using the selected page and search term.
  getTrips(
    page: number = 1,
    search: string = ''
  ): Observable<TripResponse> {

    // Sends the page number and search term to the API.
    const params = {
      page: page.toString(),
      search: search
    };

    return this.http.get<TripResponse>(
      this.apiBaseUrl,
      { params }
    );
  }

  // Adds a new trip to the database using the entered information.
  addTrip(trip: any) {
    return this.http.post(
      'http://localhost:3000/api/trips',
      trip,
      this.getAuthHeaders()
    );
  }

  // Updates an existing trip using its ID and the new information.
  updateTrip(id: string, trip: any) {
    return this.http.put(
      `http://localhost:3000/api/trips/${id}`,
      trip,
      this.getAuthHeaders()
    );
  }

  // Deletes a trip from the database using its ID.
  deleteTrip(id: string) {
    return this.http.delete(
      `http://localhost:3000/api/trips/${id}`,
      this.getAuthHeaders()
    );
  }
}