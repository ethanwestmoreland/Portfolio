import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

// Handles the login process for the Travlr administration page.
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class LoginComponent {

  // Stores the email and password entered by the user.
  email: string = '';
  password: string = '';

  constructor(private http: HttpClient, private router: Router) {}

  // Sends the login information to the API for authentication.
  login() {

    // Checks the entered credentials against the backend.
    this.http.post<any>('http://localhost:3000/api/login', {
      email: this.email,
      password: this.password
    }).subscribe({
      next: (res) => {
        console.log("LOGIN SUCCESS", res);

        // Saves the authentication token for future requests.
        localStorage.setItem('travlr-token', res.token);

        // Returns the user to the main trip management page.
        this.router.navigate(['']);
      },
      error: (err) => {
        console.error("LOGIN FAILED", err);
      }
    });
  }
}