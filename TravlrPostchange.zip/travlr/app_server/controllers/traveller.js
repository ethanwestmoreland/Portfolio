const fs = require('fs');
const axios = require('axios');

// Displays the main homepage of the Travlr website.
const index = (req, res) => {
    res.render('index', {
        title: 'Travlr Getaways',
        layout: 'layouts/main'
    });
};

// Retrieves trip information from the API and displays the travel page.
const travel = async (req, res) => {
    try {
        // Requests the available trips from the backend API.
        const response = await axios.get('http://localhost:3000/api/trips');

        // Sends the trip information to the travel page.
        res.render('travel', {
            title: 'Travel',
            layout: 'layouts/main',
            trips: response.data.trips
        });

    } catch (err) {
        // Displays an error if the trip information cannot be retrieved.
        console.log(err);
        res.status(500).send('Error retrieving trips');
    }
};

// Displays the rooms page.
const rooms = (req, res) => {
    res.render('rooms', {
        title: 'Rooms',
        layout: 'layouts/main'
    });
};

// Displays the meals page.
const meals = (req, res) => {
    res.render('meals', {
        title: 'Meals',
        layout: 'layouts/main'
    });
};

// Displays the news page.
const news = (req, res) => {
    res.render('news', {
        title: 'News',
        layout: 'layouts/main'
    });
};

// Displays the about page.
const about = (req, res) => {
    res.render('about', {
        title: 'About',
        layout: 'layouts/main'
    });
};

// Displays the contact page.
const contact = (req, res) => {
    res.render('contact', {
        title: 'Contact',
        layout: 'layouts/main'
    });
};

// Makes the page controllers available to the website routes.
module.exports = {
    index,
    travel,
    rooms,
    meals,
    news,
    about,
    contact
};