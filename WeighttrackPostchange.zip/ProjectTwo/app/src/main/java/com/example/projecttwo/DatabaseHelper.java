
package com.example.projecttwo;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/** Handles the creation and management of the WeightTrack SQLite database */
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database constants
    private static final String DATABASE_NAME = "weighttrack.db";
    private static final int DATABASE_VERSION = 2;

    // Table names
    public static final String TABLE_USERS = "users";
    public static final String TABLE_WEIGHTS = "weights";
    public static final String TABLE_GOAL = "goal";

    // Common column names
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_USER_ID = "user_id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";
    public static final String COLUMN_WEIGHT = "weight";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_GOAL_WEIGHT = "goal_weight";

    // Maximum allowed weight
    public static final double MAX_WEIGHT = 1000;

    /** Initializes the database helper */
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /** Creates the database tables when the app is first installed */
    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create the users table with unique usernames
        db.execSQL(
                "CREATE TABLE " + TABLE_USERS + " (" +
                        COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_USERNAME + " TEXT NOT NULL UNIQUE, " +
                        COLUMN_PASSWORD + " TEXT NOT NULL)"
        );

        // Create the weights table with valid weight restrictions
        db.execSQL(
                "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                        COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_USER_ID + " INTEGER NOT NULL, " +
                        COLUMN_WEIGHT + " REAL NOT NULL CHECK(weight > 0 AND weight < 1000), " +
                        COLUMN_DATE + " TEXT NOT NULL)"
        );

        // Create the goal table with one goal per user
        db.execSQL(
                "CREATE TABLE " + TABLE_GOAL + " (" +
                        COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_USER_ID + " INTEGER NOT NULL UNIQUE, " +
                        COLUMN_GOAL_WEIGHT + " REAL NOT NULL CHECK(goal_weight > 0 AND goal_weight < 1000))"
        );
    }

    /** Upgrades older databases without recreating the existing tables */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        if (oldVersion < 2) {

            // Remove duplicate usernames before creating a unique index
            db.execSQL(
                    "DELETE FROM " + TABLE_USERS +
                            " WHERE id NOT IN (" +
                            "SELECT MIN(id) FROM " + TABLE_USERS +
                            " GROUP BY username)"
            );

            // Enforce unique usernames
            db.execSQL(
                    "CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_username " +
                            "ON " + TABLE_USERS + " (" + COLUMN_USERNAME + ")"
            );

            // Keep the most recent goal for each user
            db.execSQL(
                    "DELETE FROM " + TABLE_GOAL +
                            " WHERE id NOT IN (" +
                            "SELECT MAX(id) FROM " + TABLE_GOAL +
                            " GROUP BY user_id)"
            );

            // Prevent multiple goal records for the same user
            db.execSQL(
                    "CREATE UNIQUE INDEX IF NOT EXISTS idx_unique_goal_user " +
                            "ON " + TABLE_GOAL + " (" + COLUMN_USER_ID + ")"
            );
        }
    }
}
