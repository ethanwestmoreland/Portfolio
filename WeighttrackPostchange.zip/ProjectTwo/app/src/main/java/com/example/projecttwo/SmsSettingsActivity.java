package com.example.projecttwo;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/** Handles SMS notification settings, phone numbers, and permissions */
public class SmsSettingsActivity extends AppCompatActivity {

    // Request code used when asking for SMS permission
    private static final int SMS_PERMISSION_CODE = 1;

    private Switch smsSwitch;
    private EditText phoneNumberBox;

    /** Initializes the SMS settings screen and loads saved preferences */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms);

        smsSwitch = findViewById(R.id.switch1);
        phoneNumberBox = findViewById(R.id.phoneNumberBox);

        Button savePhoneButton = findViewById(R.id.savePhoneButton);
        Button backButton = findViewById(R.id.backButton);

        SharedPreferences prefs = getSharedPreferences(
                SmsHelper.PREFS_NAME, MODE_PRIVATE);

        // Load the saved phone number
        phoneNumberBox.setText(
                prefs.getString(SmsHelper.SMS_PHONE_KEY, "")
        );

        // Load the saved notification preference
        boolean enabled = prefs.getBoolean(SmsHelper.SMS_ENABLED_KEY, false);

        // Disable notifications if SMS permission is no longer granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            enabled = false;

            prefs.edit()
                    .putBoolean(SmsHelper.SMS_ENABLED_KEY, false)
                    .apply();
        }

        smsSwitch.setChecked(enabled);

        // Enable or disable notifications when the switch is changed
        smsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                requestSmsPermission();
            } else {
                prefs.edit()
                        .putBoolean(SmsHelper.SMS_ENABLED_KEY, false)
                        .apply();
            }
        });

        // Set up the save and back buttons
        savePhoneButton.setOnClickListener(v -> savePhoneNumber());
        backButton.setOnClickListener(v -> finish());
    }

    /** Validates and saves the notification phone number */
    private void savePhoneNumber() {
        String phoneNumber = phoneNumberBox.getText().toString().trim();

        // Require exactly 10 digits
        if (!phoneNumber.matches("[0-9]{10}")) {
            phoneNumberBox.setError("Phone number must contain exactly 10 digits");
            phoneNumberBox.requestFocus();
            return;
        }

        // Save the phone number for future notifications
        getSharedPreferences(SmsHelper.PREFS_NAME, MODE_PRIVATE)
                .edit()
                .putString(SmsHelper.SMS_PHONE_KEY, phoneNumber)
                .apply();

        Toast.makeText(this, "Phone number saved",
                Toast.LENGTH_SHORT).show();
    }

    /** Requests permission before enabling SMS notifications */
    private void requestSmsPermission() {
        SharedPreferences prefs = getSharedPreferences(
                SmsHelper.PREFS_NAME, MODE_PRIVATE);

        String phoneNumber = prefs.getString(SmsHelper.SMS_PHONE_KEY, "");

        // Require a saved phone number before enabling notifications
        if (phoneNumber == null || !phoneNumber.matches("[0-9]{10}")) {
            smsSwitch.setChecked(false);

            Toast.makeText(this, "Please save a valid 10-digit phone number first",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // Check whether SMS permission has already been granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            enableSms();
        } else {

            // Request permission from the user
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        }
    }

    /** Enables notifications after permission is granted */
    private void enableSms() {
        getSharedPreferences(SmsHelper.PREFS_NAME, MODE_PRIVATE)
                .edit()
                .putBoolean(SmsHelper.SMS_ENABLED_KEY, true)
                .apply();

        Toast.makeText(this, "SMS notifications enabled",
                Toast.LENGTH_SHORT).show();
    }

    /** Handles the result of the SMS permission request */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {

            // Enable notifications if permission was granted
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enableSms();

            } else {

                // Keep notifications disabled if permission was denied
                getSharedPreferences(SmsHelper.PREFS_NAME, MODE_PRIVATE)
                        .edit()
                        .putBoolean(SmsHelper.SMS_ENABLED_KEY, false)
                        .apply();

                smsSwitch.setChecked(false);

                Toast.makeText(this, "SMS permission denied",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    /** Sends a notification when a new weight is recorded */
    public static void sendWeightNotification(Context context, double weight) {
        SmsHelper.sendWeightNotification(context, weight);
    }

    /** Sends a notification when a new goal is recorded */
    public static void sendGoalNotification(Context context, double goal) {
        SmsHelper.sendGoalNotification(context, goal);
    }
}
