package com.example.projecttwo;

import android.content.ContentValues;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/** Handles setting and updating the user's goal weight */
public class SetGoalActivity extends AppCompatActivity {

    // Preferences used to identify the logged-in user
    private static final String USER_PREFS = "UserPrefs";
    private static final String USER_ID_KEY = "userId";

    DatabaseHelper db;
    EditText goalBox;

    /** Initializes the goal weight screen and its buttons */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.goalweight);

        db = new DatabaseHelper(this);
        goalBox = findViewById(R.id.weightBox2);

        Button setGoalButton = findViewById(R.id.addWeightButton3);
        Button backButton = findViewById(R.id.backButton);

        // Set up the save and back buttons
        backButton.setOnClickListener(v -> finish());
        setGoalButton.setOnClickListener(v -> saveGoal());
    }

    /** Saves or updates the user's goal weight */
    private void saveGoal() {
        String input = goalBox.getText().toString().trim();

        // Prevent empty entries
        if (input.isEmpty()) {
            goalBox.setError("Please enter a goal weight");
            return;
        }

        double goal;

        // Prevent invalid numerical entries
        try {
            goal = Double.parseDouble(input);
        } catch (NumberFormatException e) {
            goalBox.setError("Please enter a valid number");
            return;
        }

        // Check that the goal weight is within the allowed range
        if (!Double.isFinite(goal) || goal <= 0) {
            goalBox.setError("Goal weight must be greater than zero");
            return;
        }

        if (goal >= 1000) {
            goalBox.setError("Goal weight must be less than 1000 pounds");
            return;
        }

        // Retrieve the logged in user
        SharedPreferences prefs = getSharedPreferences(USER_PREFS, MODE_PRIVATE);
        int userId = prefs.getInt(USER_ID_KEY, -1);

        if (userId == -1) {
            Toast.makeText(this, "Please log in first", Toast.LENGTH_SHORT).show();
            return;
        }

        // Prepare the goal weight information
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("goal_weight", goal);

        SQLiteDatabase database = db.getWritableDatabase();

        // Update the existing goal or create a new one
        int rowsUpdated = database.update(
                "goal", values, "user_id = ?", new String[]{String.valueOf(userId)}
        );

        if (rowsUpdated == 0) {
            long result = database.insert("goal", null, values);

            if (result == -1) {
                Toast.makeText(this, "Failed to save goal", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        Toast.makeText(this, "Goal weight saved successfully", Toast.LENGTH_SHORT).show();

        // Send a notification if SMS is enabled
        SmsSettingsActivity.sendGoalNotification(this, goal);

        // Return to the previous screen after saving
        finish();
    }
}
