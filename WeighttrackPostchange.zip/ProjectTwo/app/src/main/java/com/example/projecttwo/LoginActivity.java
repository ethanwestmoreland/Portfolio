package com.example.projecttwo;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/** Handles user login, password verification, and account authentication */
public class LoginActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private EditText usernameBox, passwordBox;

    // Preferences used to remember the logged in user
    private static final String USER_PREFS = "UserPrefs";
    private static final String USER_ID_KEY = "userId";

    /** Initializes the login screen and its buttons */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        db = new DatabaseHelper(this);

        usernameBox = findViewById(R.id.usernameBox);
        passwordBox = findViewById(R.id.passwordBox);

        Button loginButton = findViewById(R.id.loginButton);
        Button createButton = findViewById(R.id.loginButton2);

        // Set up the login button
        loginButton.setOnClickListener(v -> loginUser());

        // Open the separate registration screen
        createButton.setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class)));
    }

    /** Validates the login fields and checks the user's credentials */
    private void loginUser() {
        String username = usernameBox.getText().toString().trim();
        String password = passwordBox.getText().toString();

        // Check for missing information
        if (username.isEmpty()) {
            usernameBox.setError("Please enter your username");
            usernameBox.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            passwordBox.setError("Please enter your password");
            passwordBox.requestFocus();
            return;
        }

        SQLiteDatabase database = db.getWritableDatabase();

        int userId;
        String storedPassword;

        // Retrieve the account using its username
        try (Cursor cursor = database.rawQuery(
                "SELECT id, password FROM users WHERE username = ?",
                new String[]{username})) {

            if (!cursor.moveToFirst()) {
                showLoginError();
                return;
            }

            userId = cursor.getInt(0);
            storedPassword = cursor.getString(1);
        }

        boolean validPassword;

        try {
            // Verify the entered password against its stored hash
            if (PasswordHelper.isHashed(storedPassword)) {
                validPassword = PasswordHelper.verifyPassword(password, storedPassword);
            } else {

                // Support accounts created before password hashing
                validPassword = MessageDigest.isEqual(
                        password.getBytes(StandardCharsets.UTF_8),
                        storedPassword.getBytes(StandardCharsets.UTF_8)
                );

                if (validPassword) {

                    // Upgrade the old password after a successful login
                    ContentValues values = new ContentValues();
                    values.put(DatabaseHelper.COLUMN_PASSWORD,
                            PasswordHelper.hashPassword(password));

                    int updated = database.update(
                            DatabaseHelper.TABLE_USERS,
                            values,
                            DatabaseHelper.COLUMN_ID + " = ? AND " +
                                    DatabaseHelper.COLUMN_PASSWORD + " = ?",
                            new String[]{String.valueOf(userId), storedPassword}
                    );

                    if (updated != 1) {
                        Toast.makeText(this, "Unable to update account security",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }
                }
            }

        } catch (IllegalStateException e) {
            Toast.makeText(this, "Unable to verify password",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // Reject the login if the password does not match
        if (!validPassword) {
            showLoginError();
            return;
        }

        // Save the logged-in user's ID
        SharedPreferences prefs =
                getSharedPreferences(USER_PREFS, MODE_PRIVATE);

        prefs.edit().putInt(USER_ID_KEY, userId).apply();

        Toast.makeText(this, "Login successful",
                Toast.LENGTH_SHORT).show();

        // Open the home screen after a successful login
        startActivity(new Intent(this, HomeActivity.class));
        finish();
    }

    /** Displays an error when the login information is incorrect */
    private void showLoginError() {
        Toast.makeText(this, "Invalid username or password",
                Toast.LENGTH_SHORT).show();
    }
}
