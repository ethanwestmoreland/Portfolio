package com.example.projecttwo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/** Displays the user's goal weight and most recent weight entries */
public class HomeActivity extends AppCompatActivity {

    DatabaseHelper db;
    TextView goalWeightText;

    // Preferences used to identify the logged in user
    private static final String USER_PREFS = "UserPrefs";
    private static final String USER_ID_KEY = "userId";

    /** Initializes the home screen and navigation buttons */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);

        db = new DatabaseHelper(this);
        goalWeightText = findViewById(R.id.goalWeight);

        Button addWeightButton = findViewById(R.id.addWeightButton);
        Button smsButton = findViewById(R.id.smsButton);

        // Open the weight tracking and SMS settings screens
        addWeightButton.setOnClickListener(v -> startActivity(new Intent(this, AddWeightActivity.class)));
        smsButton.setOnClickListener(v -> startActivity(new Intent(this, SmsSettingsActivity.class)));
    }

    /** Refreshes the user's information whenever the home screen is opened */
    @Override
    protected void onResume() {
        super.onResume();

        // Reload the latest information after returning from another screen
        loadGoalWeight();
        loadLastWeights();
    }

    /** Loads the goal weight for the logged in user */
    private void loadGoalWeight() {
        SharedPreferences prefs = getSharedPreferences(USER_PREFS, MODE_PRIVATE);
        int userId = prefs.getInt(USER_ID_KEY, -1);
        if (userId == -1) return;

        SQLiteDatabase database = db.getReadableDatabase();

        // Retrieve the user's saved goal weight
        try (Cursor cursor = database.rawQuery(
                "SELECT goal_weight FROM goal WHERE user_id = ? LIMIT 1",
                new String[]{String.valueOf(userId)}
        )) {
            if (cursor.moveToFirst()) {
                goalWeightText.setText("Goal Weight: " + cursor.getDouble(0));
            } else {
                goalWeightText.setText("Goal Weight: Not Set");
            }
        }
    }

    /** Loads the last four weights for the logged-in user */
    private void loadLastWeights() {
        SharedPreferences prefs = getSharedPreferences(USER_PREFS, MODE_PRIVATE);
        int userId = prefs.getInt(USER_ID_KEY, -1);
        if (userId == -1) return;

        TextView w1 = findViewById(R.id.Weight1);
        TextView w2 = findViewById(R.id.Weight2);
        TextView w3 = findViewById(R.id.Weight3);
        TextView w4 = findViewById(R.id.Weight4);

        TextView[] boxes = {w1, w2, w3, w4};

        // Clear previous values before loading updated records
        for (TextView box : boxes) {
            box.setText("");
        }

        SQLiteDatabase database = db.getReadableDatabase();

        // Retrieve the four most recent weight entries
        try (Cursor cursor = database.rawQuery(
                "SELECT weight FROM weights WHERE user_id = ? ORDER BY id DESC LIMIT 4",
                new String[]{String.valueOf(userId)}
        )) {
            int i = 0;

            // Display each weight in its corresponding text box
            while (cursor.moveToNext() && i < boxes.length) {
                boxes[i].setText(cursor.getString(0));
                i++;
            }
        }
    }
}
