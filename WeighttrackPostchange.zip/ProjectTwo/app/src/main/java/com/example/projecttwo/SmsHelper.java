package com.example.projecttwo;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

/** Handles sending SMS notifications for weight and goal updates */
public class SmsHelper {

    // Preferences used to store SMS settings
    public static final String PREFS_NAME = "WeightPrefs";
    public static final String SMS_ENABLED_KEY = "smsEnabled";
    public static final String SMS_PHONE_KEY = "smsPhoneNumber";

    /** Sends a notification when a new weight is recorded */
    public static void sendWeightNotification(Context context, double weight) {
        String message = "WeightTrack: New weight recorded: " + weight;

        sendNotification(context, message);
    }

    /** Sends a notification when a new goal is recorded */
    public static void sendGoalNotification(Context context, double goal) {
        String message = "WeightTrack: Your new goal weight is " + goal;

        sendNotification(context, message);
    }

    /** Checks notification settings and attempts to send an SMS */
    private static void sendNotification(Context context, String message) {
        SharedPreferences prefs = context.getSharedPreferences(
                PREFS_NAME, Context.MODE_PRIVATE);

        // Retrieve the saved notification settings
        boolean smsEnabled = prefs.getBoolean(SMS_ENABLED_KEY, false);
        String phoneNumber = prefs.getString(SMS_PHONE_KEY, "");

        // Do not send if notifications are disabled
        if (!smsEnabled) {
            return;
        }

        // Ensure a valid recipient has been configured
        if (phoneNumber == null || !phoneNumber.matches("[0-9]{10}")) {
            return;
        }

        // Verify SMS permission before sending
        if (ContextCompat.checkSelfPermission(
                context, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        // Attempt to send the notification to the saved phone number
        try {
            SmsManager smsManager = SmsManager.getDefault();

            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    message,
                    null,
                    null
            );

        } catch (Exception e) {
            // Display an error if the notification cannot be sent
            Toast.makeText(context,
                    "Unable to send SMS notification",
                    Toast.LENGTH_SHORT).show();
        }
    }
}
