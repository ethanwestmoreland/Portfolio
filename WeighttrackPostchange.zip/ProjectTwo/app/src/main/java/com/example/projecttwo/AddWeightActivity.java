package com.example.projecttwo;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.time.LocalDate;

/** Handles adding new weight entries for the logged in user */
public class AddWeightActivity extends AppCompatActivity {

    // Preferences used to identify the logged-in user
    private static final String USER_PREFS = "UserPrefs";
    private static final String USER_ID_KEY = "userId";

    private DatabaseHelper db;
    private EditText weightBox;

    /** Initializes the weight entry screen and its buttons */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addweight);

        db = new DatabaseHelper(this);
        weightBox = findViewById(R.id.weightBox);

        Button addWeightButton = findViewById(R.id.addWeightButton2);
        Button editGoalButton = findViewById(R.id.editGoalButton);
        Button homeButton = findViewById(R.id.returnToHome);

        // Set up the weight entry and navigation buttons
        addWeightButton.setOnClickListener(v -> addWeight());

        editGoalButton.setOnClickListener(v ->
                startActivity(new Intent(this, SetGoalActivity.class)));

        homeButton.setOnClickListener(v -> finish());
    }

    /** Validates and saves a weight entry for the logged in user */
    private void addWeight() {
        String input = weightBox.getText().toString().trim();

        // Prevent empty entries
        if (input.isEmpty()) {
            weightBox.setError("Please enter your weight");
            weightBox.requestFocus();
            return;
        }

        double weight;

        // Prevent invalid numerical entries
        try {
            weight = Double.parseDouble(input);
        } catch (NumberFormatException e) {
            weightBox.setError("Please enter a valid number");
            weightBox.requestFocus();
            return;
        }

        // Prevent zero, negative, and non-finite values
        if (!Double.isFinite(weight) || weight <= 0) {
            weightBox.setError("Weight must be greater than zero");
            weightBox.requestFocus();
            return;
        }

        // Retrieve the logged in user
        SharedPreferences prefs = getSharedPreferences(USER_PREFS, MODE_PRIVATE);

        int userId = prefs.getInt(USER_ID_KEY, -1);

        if (userId == -1) {
            Toast.makeText(this, "Please log in first",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // Prepare the weight entry with the current date
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("weight", weight);
        values.put("date", LocalDate.now().toString());

        SQLiteDatabase database = db.getWritableDatabase();

        // Save the weight entry to the database
        long result = database.insert("weights", null, values);

        // Check whether the entry was saved
        if (result == -1) {
            Toast.makeText(this, "Failed to save weight", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Weight saved successfully", Toast.LENGTH_SHORT).show();

        // Send a notification if SMS is enabled
        SmsSettingsActivity.sendWeightNotification(this, weight);

        // Return to the home screen after saving
        startActivity(new Intent(this, HomeActivity.class));
        finish();
    }
}
