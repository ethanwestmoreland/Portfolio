package com.example.projecttwo;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/** Handles user registration, input validation, and account creation */
public class RegisterActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private EditText usernameBox, passwordBox;

    // Minimum required password length
    private static final int MIN_PASSWORD_LENGTH = 8;

    /** Initializes the registration screen and its buttons */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        db = new DatabaseHelper(this);

        usernameBox = findViewById(R.id.usernameBox);
        passwordBox = findViewById(R.id.passwordBox);

        Button registerButton = findViewById(R.id.registerButton);
        Button backButton = findViewById(R.id.backButton);

        // Set up the registration and back buttons
        registerButton.setOnClickListener(v -> createUser());
        backButton.setOnClickListener(v -> finish());
    }

    /** Validates registration information before creating an account */
    private void createUser() {
        String username = usernameBox.getText().toString().trim();
        String password = passwordBox.getText().toString();

        // Check that the username meets the requirements
        if (username.isEmpty()) {
            usernameBox.setError("Username cannot be empty");
            usernameBox.requestFocus();
            return;
        }

        if (username.length() < 3) {
            usernameBox.setError("Username must contain at least 3 characters");
            usernameBox.requestFocus();
            return;
        }

        // Check the minimum password length
        if (password.length() < MIN_PASSWORD_LENGTH) {
            passwordBox.setError("Password must contain at least 8 characters");
            passwordBox.requestFocus();
            return;
        }

        SQLiteDatabase database = db.getWritableDatabase();

        // Check whether the username already exists
        try (Cursor cursor = database.rawQuery(
                "SELECT id FROM users WHERE username = ?",
                new String[]{username})) {

            if (cursor.moveToFirst()) {
                usernameBox.setError("Username already exists");
                usernameBox.requestFocus();
                return;
            }
        }

        // Hash the password before storing it
        String hashedPassword;

        try {
            hashedPassword = PasswordHelper.hashPassword(password);
        } catch (IllegalStateException e) {
            Toast.makeText(this, "Unable to secure password",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // Prepare the new account information
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_USERNAME, username);
        values.put(DatabaseHelper.COLUMN_PASSWORD, hashedPassword);

        // Insert the account into the database
        long result = database.insert(DatabaseHelper.TABLE_USERS, null, values);

        if (result == -1) {
            Toast.makeText(this, "Account creation failed",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Account created successfully!",
                Toast.LENGTH_SHORT).show();

        // Return to the login screen
        finish();
    }
}
