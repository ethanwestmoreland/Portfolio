
package com.example.projecttwo;

import android.util.Base64;

import java.security.SecureRandom;
import java.security.MessageDigest;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Handles secure password hashing and verification */
public class PasswordHelper {

    // Settings used to generate and store password hashes
    private static final int ITERATIONS = 210000;
    private static final int SALT_LENGTH = 16;
    private static final int KEY_LENGTH = 256;
    private static final String ALGORITHM = "PBKDF2WithHmacSHA1";
    private static final String PREFIX = "pbkdf2";

    /** Creates a salted password hash for database storage */
    public static String hashPassword(String password) {

        // Generate a random salt for each password
        byte[] salt = new byte[SALT_LENGTH];
        new SecureRandom().nextBytes(salt);

        // Generate the hash using the password and salt
        byte[] hash = generateHash(password, salt, ITERATIONS);

        // Store the algorithm prefix, iterations, salt, and hash together
        return PREFIX + "$" + ITERATIONS + "$" +
                Base64.encodeToString(salt, Base64.NO_WRAP) + "$" +
                Base64.encodeToString(hash, Base64.NO_WRAP);
    }

    /** Verifies a password against its stored hash */
    public static boolean verifyPassword(String password, String storedPassword) {
        if (!isHashed(storedPassword)) {
            return false;
        }

        try {
            // Separate the stored password into its individual parts
            String[] parts = storedPassword.split("\\$");

            if (parts.length != 4) {
                return false;
            }

            // Retrieve and validate the original iteration count
            int iterations = Integer.parseInt(parts[1]);

            if (iterations < 1 || iterations > ITERATIONS) {
                return false;
            }

            // Decode the stored salt and password hash
            byte[] salt = Base64.decode(parts[2], Base64.NO_WRAP);
            byte[] storedHash = Base64.decode(parts[3], Base64.NO_WRAP);

            if (salt.length != SALT_LENGTH || storedHash.length != KEY_LENGTH / 8) {
                return false;
            }

            // Generate a new hash using the entered password
            byte[] enteredHash = generateHash(password, salt, iterations);

            // Compare the generated hash with the stored hash
            return MessageDigest.isEqual(storedHash, enteredHash);

        } catch (Exception e) {
            return false;
        }
    }

    /** Checks whether a stored password uses the new format */
    public static boolean isHashed(String storedPassword) {
        return storedPassword != null && storedPassword.startsWith(PREFIX + "$");
    }

    /** Generates a password hash using PBKDF2 */
    private static byte[] generateHash(String password, byte[] salt, int iterations) {
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, iterations, KEY_LENGTH);

        try {
            // Generate the password hash using the selected algorithm
            SecretKeyFactory factory = SecretKeyFactory.getInstance(ALGORITHM);
            return factory.generateSecret(spec).getEncoded();

        } catch (Exception e) {
            throw new IllegalStateException("Password hashing failed", e);

        } finally {
            // Clear the password from the hashing specification
            spec.clearPassword();
        }
    }
}
