const express = require('express');
const cors = require('cors');

const app = express();
const port = 3000;

app.use(cors({
  origin: 'http://localhost:4200'
}));

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

require('./app_api/models/db');

const apiRouter = require('./app_api/routes/index');
app.use('/api', apiRouter);

const path = require('path');
const hbs = require('hbs');

app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'app_server', 'views'));

hbs.registerPartials(path.join(__dirname, 'app_server', 'views', 'partials'));

app.use(express.static(path.join(__dirname, 'public')));

const indexRouter = require('./app_server/routes/index');
app.use('/', indexRouter);

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});