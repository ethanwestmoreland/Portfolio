const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');

require('./db');
const Trip = mongoose.model('trips');

const tripsPath = path.join(__dirname, '../../data/trips.json');
const tripsData = JSON.parse(fs.readFileSync(tripsPath, 'utf8'));

const seedDB = async () => {
    try {
        await Trip.deleteMany({});
        await Trip.insertMany(tripsData.trips);
        console.log('Database successfully seeded');
        mongoose.connection.close();
    } catch (err) {
        console.log(err);
        mongoose.connection.close();
    }
};

seedDB();