const mongoose = require('mongoose');

const tripSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Trip name is required'],
        trim: true
    },
    image: {
        type: String,
        default: 'default.jpg'
    },
    description1: {
        type: String,
        required: [true, 'Primary description is required']
    },
    description2: {
        type: String,
        required: [true, 'Secondary description is required']
    }
});

mongoose.model('trips', tripSchema);