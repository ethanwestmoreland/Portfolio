const mongoose = require('mongoose');

const dbURI = 'mongodb://127.0.0.1:27017/travlr';

mongoose.connect(dbURI);

mongoose.connection.on('connected', () => {
    console.log(`Mongoose connected to ${dbURI}`);
});

mongoose.connection.on('error', (err) => {
    console.log('Mongoose connection error: ' + err);
});

mongoose.connection.on('disconnected', () => {
    console.log('Mongoose disconnected');
});

require('./travlr');
require('./users');


const User = mongoose.model('users');

const seedUser = async () => {
    try {
        const existingUser = await User.findOne({ email: 'admin@test.com' });

        if (!existingUser) {
            const user = new User();
            user.email = 'admin@test.com';
            user.setPassword('123456');

            await user.save();
            console.log('Default user created: admin@test.com / 123456');
        } else {
            console.log('Default user already exists');
        }
    } catch (err) {
        console.error('Error seeding user:', err);
    }
};

seedUser();

const gracefulShutdown = (msg, callback) => {
    mongoose.connection.close(() => {
        console.log(`Mongoose disconnected through ${msg}`);
        callback();
    });
};

process.once('SIGUSR2', () => {
    gracefulShutdown('nodemon restart', () => {
        process.kill(process.pid, 'SIGUSR2');
    });
});

process.on('SIGINT', () => {
    gracefulShutdown('app termination', () => {
        process.exit(0);
    });
});

process.on('SIGTERM', () => {
    gracefulShutdown('Heroku app shutdown', () => {
        process.exit(0);
    });
});