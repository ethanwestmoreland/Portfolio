const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const User = mongoose.model('users');

const register = async (req, res) => {
  const user = new User();
  user.email = req.body.email;
  user.setPassword(req.body.password);

  try {
    await user.save();
    res.status(200).json({ message: "User created" });
  } catch (err) {
    res.status(400).json(err);
  }
};

const login = async (req, res) => {
  const user = await User.findOne({ email: req.body.email });

  if (!user || !user.validPassword(req.body.password)) {
    return res.status(401).json({ message: "Invalid credentials" });
  }

  const token = jwt.sign(
    { _id: user._id, email: user.email },
    "MY_SECRET_KEY"
  );

  res.status(200).json({ token });
};

module.exports = {
  register,
  login
};