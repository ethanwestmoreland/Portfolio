const express = require('express');
const router = express.Router();
const ctrlTrips = require('../controllers/trips');
const ctrlAuth = require('../controllers/authentication');

const { expressjwt: jwt } = require('express-jwt');

const auth = jwt({
  secret: "MY_SECRET_KEY",
  algorithms: ["HS256"]
});

router.post('/register', ctrlAuth.register);
router.post('/login', ctrlAuth.login);

router.get('/trips', ctrlTrips.tripsList);
router.get('/trips/:tripId', ctrlTrips.tripsFindById);

router.post('/trips', auth, ctrlTrips.tripsAdd);

router.put('/trips/:tripId', auth, ctrlTrips.tripsUpdate);

router.delete('/trips/:tripId', auth, ctrlTrips.tripsDelete);

module.exports = router;