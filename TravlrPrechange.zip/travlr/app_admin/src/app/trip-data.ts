import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Trip } from './trip';

@Injectable({
  providedIn: 'root'
})
export class TripDataService {

  private apiBaseUrl = 'http://localhost:3000/api/trips';

  constructor(private http: HttpClient) {}

  getAuthHeaders() {
    const token = localStorage.getItem('travlr-token');

    return {
      headers: {
        Authorization: `Bearer ${token}`
      }
    };
}

  getTrips(): Observable<Trip[]> {
    return this.http.get<Trip[]>(this.apiBaseUrl);
  }
  addTrip(trip: any) {
    return this.http.post(
      'http://localhost:3000/api/trips',
      trip,
      this.getAuthHeaders()
    );
  }
  updateTrip(id: string, trip: any) {
    return this.http.put(
      `http://localhost:3000/api/trips/${id}`,
      trip,
      this.getAuthHeaders()
    );
  }
  deleteTrip(id: string) {
    return this.http.delete(
      `http://localhost:3000/api/trips/${id}`,
      this.getAuthHeaders()
    );
  }
}
