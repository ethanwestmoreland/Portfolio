import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class LoginComponent {

  email: string = '';
  password: string = '';

  constructor(private http: HttpClient, private router: Router) {}

  login() {
  this.http.post<any>('http://localhost:3000/api/login', {
    email: this.email,
    password: this.password
  }).subscribe({
    next: (res) => {
      console.log("LOGIN SUCCESS", res);

      localStorage.setItem('travlr-token', res.token);

      this.router.navigate(['']);
    },
    error: (err) => {
      console.error("LOGIN FAILED", err);
    }
  });
}
}