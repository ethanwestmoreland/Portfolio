import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs';
import { CommonModule } from '@angular/common';
import { TripDataService } from '../trip-data';
import { Trip } from '../trip';
import { TripFormComponent } from '../trip-form/trip-form';
import { Router } from '@angular/router';

@Component({
  selector: 'app-trip-list',
  standalone: true,
  imports: [CommonModule, TripFormComponent],
  templateUrl: './trip-list.html',
  styleUrls: ['./trip-list.css']
})

export class TripListComponent implements OnInit {

  trips$!: Observable<Trip[]>;

  selectedTrip: Trip | null = null;

  constructor(
    private tripService: TripDataService,
    private router: Router
  ) {}

  isLoggedIn(): boolean {
    return !!localStorage.getItem('travlr-token');
  }

  ngOnInit(): void {
    this.trips$ = this.tripService.getTrips();
  }

  selectTrip(trip: Trip) {
    this.selectedTrip = trip;
  }

  cancelEdit() {
    this.selectedTrip = null;
  }

  logout() {
    localStorage.removeItem('travlr-token');
    this.selectedTrip = null;
  }

  goToLogin() {
    this.router.navigate(['/login']);
  }

  deleteTrip(id: string | undefined) {
    console.log("DELETE CLICKED", id);

    if (!id) return;

    if (confirm('Are you sure you want to delete this trip?')) {
      this.tripService.deleteTrip(id).subscribe({
        next: () => {
          console.log("DELETE SUCCESS");
          alert('Trip deleted!');
          window.location.reload();
        },
        error: (err) => console.error("DELETE ERROR", err)
      });
    }
  }
}