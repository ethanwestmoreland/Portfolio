import { Component, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { TripDataService } from '../trip-data';
import { Trip } from '../trip';
import { Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-trip-form',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './trip-form.html',
  styleUrls: ['./trip-form.css']
})
export class TripFormComponent {

  isEditing: boolean = false;

  @Input() selectedTrip: any = null;
  @Output() cancel = new EventEmitter<void>();

  newTrip: Trip = {
    name: '',
    image: '',
    description1: '',
    description2: ''
  };

  constructor(private tripService: TripDataService) {}

  ngOnChanges() {
    if (this.selectedTrip) {
      this.newTrip = { ...this.selectedTrip };
      this.isEditing = true;
    } else {
      this.resetForm();
      this.isEditing = false;
    }
  }

  onCancel() {
    this.resetForm();
    this.cancel.emit();
  }

  saveTrip() {
  const tripData = {
    name: this.newTrip.name,
    image: this.newTrip.image,
    description1: this.newTrip.description1,
    description2: this.newTrip.description2
  };

  if (this.selectedTrip && this.selectedTrip._id) {
    this.tripService.updateTrip(this.selectedTrip._id, tripData).subscribe({
      next: () => {
        alert('Trip updated!');
        this.resetForm();
        window.location.reload();
      },
      error: (err) => console.error(err)
    });
  } else {
    this.tripService.addTrip(tripData).subscribe({
      next: () => {
        alert('Trip added!');
        this.resetForm();
        window.location.reload();
      },
      error: (err) => console.error(err)
    });
  }
}
resetForm() {
  this.newTrip = {
    name: '',
    image: '',
    description1: '',
    description2: ''
  };

  this.cancel.emit();
}
}