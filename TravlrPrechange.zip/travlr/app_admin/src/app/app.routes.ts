import { Routes } from '@angular/router';
import { LoginComponent } from './login/login';
import { TripListComponent } from './trip-list/trip-list';



export const routes: Routes = [
  { path: '', component: TripListComponent, pathMatch: 'full' },
  { path: 'login', component: LoginComponent }
];