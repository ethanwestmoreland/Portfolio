export interface Trip {
  _id?: string;
  name: string;
  image: string;
  description1: string;
  description2: string;
}