const fs = require('fs');
const axios = require('axios');

const index = (req, res) => {
    res.render('index', {
        title: 'Travlr Getaways',
        layout: 'layouts/main'
    });
};

const travel = async (req, res) => {
    try {
        const response = await axios.get('http://localhost:3000/api/trips');

        res.render('travel', {
            title: 'Travel',
            layout: 'layouts/main',
            trips: response.data
        });
    } catch (err) {
        console.log(err);
        res.status(500).send('Error retrieving trips');
    }
};

const rooms = (req, res) => {
    res.render('rooms', {
        title: 'Rooms',
        layout: 'layouts/main'
    });
};

const meals = (req, res) => {
    res.render('meals', {
        title: 'Meals',
        layout: 'layouts/main'
    });
};

const news = (req, res) => {
    res.render('news', {
        title: 'News',
        layout: 'layouts/main'
    });
};

const about = (req, res) => {
    res.render('about', {
        title: 'About',
        layout: 'layouts/main'
    });
};

const contact = (req, res) => {
    res.render('contact', {
        title: 'Contact',
        layout: 'layouts/main'
    });
};

module.exports = {
    index,
    travel,
    rooms,
    meals,
    news,
    about,
    contact
};