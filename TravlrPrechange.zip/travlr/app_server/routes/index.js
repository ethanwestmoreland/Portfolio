const express = require('express');
const router = express.Router();

const ctrlTraveller = require('../controllers/traveller');

// Home page
router.get('/', ctrlTraveller.index);

// Travel page
router.get('/travel', ctrlTraveller.travel);

// Rooms page
router.get('/rooms', ctrlTraveller.rooms);

// Meals page
router.get('/meals', ctrlTraveller.meals);

// News page
router.get('/news', ctrlTraveller.news);

// About page
router.get('/about', ctrlTraveller.about);

// Contact page
router.get('/contact', ctrlTraveller.contact);

module.exports = router;